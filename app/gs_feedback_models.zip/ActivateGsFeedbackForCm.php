<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Auth;

class ActivateGsFeedbackForCm extends Model {

    protected $primaryKey = 'id';
    protected $table = 'activate_gs_feedback_for_cm';
    public $timestamps = false;


}
