<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Auth;

class ActivateGsFeedbackForDs extends Model {

    protected $primaryKey = 'id';
    protected $table = 'activate_gs_feedback_for_ds';
    public $timestamps = false;


}
