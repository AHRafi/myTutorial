{!! Form::select('sub_event_id', $subEventList, null,  ['class' => 'form-control js-source-states', 'id' => 'subEventId']) !!}
