{!!  Form::select('thana_id', $thanaList,  null, ['class' => 'form-control js-states' ]) !!}
