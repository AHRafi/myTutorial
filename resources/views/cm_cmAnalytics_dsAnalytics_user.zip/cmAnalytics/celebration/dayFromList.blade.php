{!! Form::select('day_from', $dayList,  null, ['class' => 'form-control js-source-states', 'id' => 'dayFrom']) !!}
