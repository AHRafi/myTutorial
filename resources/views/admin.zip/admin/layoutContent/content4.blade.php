<div class="font-white dashboard-title-back-style margin-bottom-10">
    <h4 class="text-center bold">@lang('label.ABSENT') (@lang('label.TODAY'))</h4>
</div>
<div id="absentChartDiv" style="min-width:250px; height: 300px; margin: 0 auto;"></div>